import { useState } from 'react';
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { TrendingUp, Users, ShoppingCart, Zap, Target, RefreshCw } from 'lucide-react';

/**
 * Dashboard XETRO - Los Paisanito
 * Análisis de Marketing Digital con Método XETRO
 * Paleta: #a445ff (púrpura), #1c003d (azul oscuro), blanco
 * Tipografía: Poppins (títulos), Inter (cuerpo), IBM Plex Mono (datos)
 */

export default function Home() {
  const [selectedPeriod, setSelectedPeriod] = useState('diciembre');

  // Datos de Ventas
  const ventasData = {
    total_pedidos_validos: 512,
    total_facturado: 43860860,
    ticket_promedio: 85665.74,
    pedidos_pendientes: 998,
    pedidos_cancelados: 60,
    tasa_cancelacion: 10.5,
  };

  // Datos de Meta Ads
  const metaAdsData = {
    inversion_total: 611380.58,
    total_mensajes: 1137,
    costo_promedio_mensaje: 537.71,
    roas: 71.74,
    tasa_conversion: 45.03,
  };

  // Datos para gráficos
  const ventasPorEstado = [
    { name: 'Pedido realizado', value: 295, fill: '#a445ff' },
    { name: 'Confirmado', value: 189, fill: '#7c3acc' },
    { name: 'En Preparación', value: 25, fill: '#6b2fb8' },
    { name: 'Entregado', value: 3, fill: '#1c003d' },
  ];

  const campanasEficiencia = [
    { name: 'Casa Central - Bot', costo: 140.30, mensajes: 739 },
    { name: 'Influencer código', costo: 165.37, mensajes: 251 },
    { name: 'Carne-BOT', costo: 147.14, mensajes: 128 },
    { name: 'Catalogo Central', costo: 20710.10, mensajes: 10 },
    { name: 'Catalogo Francisco', costo: 26695.17, mensajes: 9 },
  ];

  const metricasXETRO = [
    {
      pilar: 'Experiencia',
      icono: Users,
      valor: '512',
      descripcion: 'Pedidos válidos completados',
      color: '#a445ff',
      detalle: 'Tasa de conversión: 45.03%'
    },
    {
      pilar: 'Emoción',
      icono: Target,
      valor: '1,137',
      descripcion: 'Conversaciones iniciadas',
      color: '#7c3acc',
      detalle: 'Engagement en Meta Ads'
    },
    {
      pilar: 'Tráfico',
      icono: TrendingUp,
      valor: '711K',
      descripcion: 'Alcance total',
      color: '#6b2fb8',
      detalle: '2.1M impresiones'
    },
    {
      pilar: 'Retención',
      icono: ShoppingCart,
      valor: '$43.8M',
      descripcion: 'Facturación válida',
      color: '#5a24a4',
      detalle: 'Ticket promedio: $85,666'
    },
    {
      pilar: 'Optimización',
      icono: Zap,
      valor: '71.74x',
      descripcion: 'ROAS',
      color: '#1c003d',
      detalle: 'Retorno de inversión'
    },
  ];

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('es-AR', {
      style: 'currency',
      currency: 'ARS',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value);
  };

  const formatNumber = (value: number) => {
    return new Intl.NumberFormat('es-AR').format(Math.round(value));
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Sidebar */}
      <div className="fixed left-0 top-0 h-screen w-64 bg-sidebar text-sidebar-foreground p-6 overflow-y-auto border-r border-sidebar-border">
        <div className="mb-8">
          <h1 style={{ fontFamily: 'Poppins', fontWeight: 800 }} className="text-2xl text-white mb-2">XETRO</h1>
          <p className="text-sm text-sidebar-accent">Los Paisanito</p>
        </div>

        <nav className="space-y-4">
          <div className="text-xs font-mono uppercase text-sidebar-accent mb-4">Pilares XETRO</div>
          {metricasXETRO.map((item, idx) => (
            <button
              key={idx}
              className="w-full text-left px-4 py-3 rounded-lg hover:bg-sidebar-accent/10 transition-colors text-sm font-medium"
            >
              {item.pilar}
            </button>
          ))}
        </nav>

        <div className="mt-8 pt-8 border-t border-sidebar-border">
          <p className="text-xs text-sidebar-foreground/60 mb-4">Período</p>
          <Button
            variant={selectedPeriod === 'diciembre' ? 'default' : 'outline'}
            className="w-full mb-2 text-sm"
            onClick={() => setSelectedPeriod('diciembre')}
          >
            Diciembre 2025
          </Button>
          <Button
            variant={selectedPeriod === 'enero' ? 'default' : 'outline'}
            className="w-full text-sm"
            onClick={() => setSelectedPeriod('enero')}
            disabled
          >
            Enero 2026 (próximamente)
          </Button>
        </div>
      </div>

      {/* Contenido Principal */}
      <div className="ml-64 p-8">
        {/* Header */}
        <div className="mb-8">
          <h2 style={{ fontFamily: 'Poppins', fontWeight: 800 }} className="text-4xl text-foreground mb-2">Dashboard XETRO</h2>
          <p className="text-muted-foreground">Análisis de Marketing Digital - Los Paisanito</p>
          <p className="text-sm text-muted-foreground mt-2">Diciembre 2025 | Datos consolidados</p>
        </div>

        {/* KPI Principal */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="kpi-card">
            <div className="kpi-label">Facturación Total</div>
            <div className="kpi-value mt-2">{formatCurrency(ventasData.total_facturado)}</div>
            <div className="text-xs text-muted-foreground mt-3">512 pedidos válidos</div>
          </Card>

          <Card className="kpi-card">
            <div className="kpi-label">ROAS (Retorno de Inversión)</div>
            <div className="kpi-value mt-2 text-primary">{metaAdsData.roas.toFixed(2)}x</div>
            <div className="text-xs text-muted-foreground mt-3">Inversión: {formatCurrency(metaAdsData.inversion_total)}</div>
          </Card>

          <Card className="kpi-card">
            <div className="kpi-label">Ticket Promedio</div>
            <div className="kpi-value mt-2">{formatCurrency(ventasData.ticket_promedio)}</div>
            <div className="text-xs text-muted-foreground mt-3">Por pedido válido</div>
          </Card>
        </div>

        {/* Pilares XETRO */}
        <div className="mb-8">
          <h3 style={{ fontFamily: 'Poppins', fontWeight: 800 }} className="text-2xl text-foreground mb-6">Pilares XETRO</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
            {metricasXETRO.map((item, idx) => {
              const IconComponent = item.icono;
              return (
                <Card key={idx} className="kpi-card">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <div className="kpi-label">{item.pilar}</div>
                      <div className="kpi-value mt-2 text-lg" style={{ color: item.color }}>
                        {item.valor}
                      </div>
                    </div>
                    <IconComponent className="w-5 h-5" style={{ color: item.color }} />
                  </div>
                  <p className="text-xs text-muted-foreground mb-2">{item.descripcion}</p>
                  <p className="text-xs font-mono text-primary">{item.detalle}</p>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Gráficos */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Distribución de Ventas */}
          <Card className="kpi-card p-6">
            <h4 style={{ fontFamily: 'Poppins', fontWeight: 700 }} className="text-lg text-foreground mb-6">Distribución de Pedidos Válidos</h4>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={ventasPorEstado}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, value }) => `${name}: ${value}`}
                  outerRadius={100}
                  fill="#a445ff"
                  dataKey="value"
                >
                  {ventasPorEstado.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.fill} />
                  ))}
                </Pie>
                <Tooltip formatter={(value) => formatNumber(value as number)} />
              </PieChart>
            </ResponsiveContainer>
          </Card>

          {/* Eficiencia de Campañas */}
          <Card className="kpi-card p-6">
            <h4 style={{ fontFamily: 'Poppins', fontWeight: 700 }} className="text-lg text-foreground mb-6">Eficiencia de Campañas Meta Ads</h4>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={campanasEficiencia}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis dataKey="name" angle={-45} textAnchor="end" height={100} tick={{ fontSize: 12 }} />
                <YAxis label={{ value: 'Costo por Mensaje (ARS)', angle: -90, position: 'insideLeft' }} />
                <Tooltip formatter={(value) => `$${(value as number).toFixed(2)}`} />
                <Bar dataKey="costo" fill="#a445ff" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </Card>
        </div>

        {/* Análisis Detallado */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Ventas */}
          <Card className="kpi-card p-6">
            <h4 style={{ fontFamily: 'Poppins', fontWeight: 700 }} className="text-lg text-foreground mb-6">Resumen de Ventas</h4>
            <div className="space-y-4">
              <div className="flex justify-between items-center pb-4 border-b border-border">
                <span className="text-muted-foreground">Pedidos Válidos</span>
                <span className="font-mono text-lg font-bold text-primary">{formatNumber(ventasData.total_pedidos_validos)}</span>
              </div>
              <div className="flex justify-between items-center pb-4 border-b border-border">
                <span className="text-muted-foreground">Facturación Total</span>
                <span className="font-mono text-lg font-bold text-primary">{formatCurrency(ventasData.total_facturado)}</span>
              </div>
              <div className="flex justify-between items-center pb-4 border-b border-border">
                <span className="text-muted-foreground">Ticket Promedio</span>
                <span className="font-mono text-lg font-bold text-primary">{formatCurrency(ventasData.ticket_promedio)}</span>
              </div>
              <div className="flex justify-between items-center pb-4 border-b border-border">
                <span className="text-muted-foreground">Pedidos Pendientes</span>
                <span className="font-mono text-lg font-bold text-yellow-600">{formatNumber(ventasData.pedidos_pendientes)}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Pedidos Cancelados</span>
                <span className="font-mono text-lg font-bold text-red-600">{formatNumber(ventasData.pedidos_cancelados)}</span>
              </div>
            </div>
          </Card>

          {/* Meta Ads */}
          <Card className="kpi-card p-6">
            <h4 style={{ fontFamily: 'Poppins', fontWeight: 700 }} className="text-lg text-foreground mb-6">Desempeño Meta Ads</h4>
            <div className="space-y-4">
              <div className="flex justify-between items-center pb-4 border-b border-border">
                <span className="text-muted-foreground">Inversión Total</span>
                <span className="font-mono text-lg font-bold text-primary">{formatCurrency(metaAdsData.inversion_total)}</span>
              </div>
              <div className="flex justify-between items-center pb-4 border-b border-border">
                <span className="text-muted-foreground">Mensajes Iniciados</span>
                <span className="font-mono text-lg font-bold text-primary">{formatNumber(metaAdsData.total_mensajes)}</span>
              </div>
              <div className="flex justify-between items-center pb-4 border-b border-border">
                <span className="text-muted-foreground">Costo por Mensaje</span>
                <span className="font-mono text-lg font-bold text-primary">${metaAdsData.costo_promedio_mensaje.toFixed(2)}</span>
              </div>
              <div className="flex justify-between items-center pb-4 border-b border-border">
                <span className="text-muted-foreground">Tasa de Conversión</span>
                <span className="font-mono text-lg font-bold text-primary">{metaAdsData.tasa_conversion.toFixed(2)}%</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">ROAS</span>
                <span className="font-mono text-lg font-bold text-primary">{metaAdsData.roas.toFixed(2)}x</span>
              </div>
            </div>
          </Card>
        </div>

        {/* Recomendaciones */}
        <Card className="kpi-card p-6 mb-8">
          <h4 style={{ fontFamily: 'Poppins', fontWeight: 700 }} className="text-lg text-foreground mb-4">Recomendaciones Clave</h4>
          <div className="space-y-4">
            <div className="flex gap-4">
              <div className="w-1 bg-primary rounded-full"></div>
              <div>
                <p className="font-medium text-foreground">Optimizar Flujo de Conversión</p>
                <p className="text-sm text-muted-foreground">998 pedidos pendientes representan $53M en oportunidad. Investigar causas de abandono.</p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="w-1 bg-primary rounded-full"></div>
              <div>
                <p className="font-medium text-foreground">Escalar Campañas Eficientes</p>
                <p className="text-sm text-muted-foreground">"Casa Central - Bot" demuestra máxima eficiencia ($140/msg). Aumentar inversión en este modelo.</p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="w-1 bg-primary rounded-full"></div>
              <div>
                <p className="font-medium text-foreground">Auditar Campañas Ineficientes</p>
                <p className="text-sm text-muted-foreground">"Catalogo Francisco" ($26,695/msg) requiere revisión urgente de segmentación y creatividad.</p>
              </div>
            </div>
          </div>
        </Card>

        {/* Footer */}
        <div className="text-center text-sm text-muted-foreground pb-8">
          <p>Dashboard XETRO - Diciembre 2025 | Datos consolidados al 13 de enero de 2026</p>
          <p className="mt-2">Próximamente: Comparativa con enero 2026 y análisis histórico mensual</p>
        </div>
      </div>
    </div>
  );
}
